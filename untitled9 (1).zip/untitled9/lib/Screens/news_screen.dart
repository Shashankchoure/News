import 'package:flutter/material.dart';
import 'package:untitled9/Screens/LoginScreen.dart';
import 'package:untitled9/Model/news_model.dart';
import '../Services/Api_data.dart';

class NewsScreen extends StatefulWidget {
  const NewsScreen({Key? key, required this.categoryUrl}) : super(key: key);
  final String categoryUrl;

  @override
  State<NewsScreen> createState() => _NewsScreenState();
}

class _NewsScreenState extends State<NewsScreen> {
  List<NewsData>? allNews;
  bool loading = true;

  @override
  void initState() {
    getNews();
    super.initState();
  }

  void getNews() async {
    allNews =
        (await StatesServices().fetchWorkedStatesRecords(widget.categoryUrl));
    setState(() {
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return loading
        ? const Center(
            child: CircularProgressIndicator(),
          )
        : ListView.builder(
            itemBuilder: (context, index) {
              return InkWell(
                onTap: () {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => LoginScreen()));
                },
                child: ListTile(
                  leading: Image.network(
                    allNews![index].imageUrl ?? '',
                  ),
                  title: Text(
                    allNews![0].title ?? 'N/A',
                  ),
                  subtitle: Text(
                    allNews![0].content ?? 'N/A',
                  ),
                ),
              );
            },
            itemCount: allNews?.length,
          );
  }
}
